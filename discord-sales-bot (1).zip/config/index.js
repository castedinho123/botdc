require('dotenv').config();

module.exports = {
  discord: {
    token: process.env.DISCORD_TOKEN,
    clientId: process.env.CLIENT_ID,
    guildId: process.env.GUILD_ID,
  },

  supabase: {
    url: process.env.SUPABASE_URL,
    anonKey: process.env.SUPABASE_ANON_KEY,
    serviceKey: process.env.SUPABASE_SERVICE_KEY,
  },

  mercadoPago: {
    accessToken: process.env.MERCADOPAGO_ACCESS_TOKEN,
    webhookSecret: process.env.MERCADOPAGO_WEBHOOK_SECRET,
  },

  store: {
    name: process.env.STORE_NAME || 'MinhaLoja 🛒',
    color: process.env.STORE_COLOR || '#5865F2',
    logoUrl: process.env.STORE_LOGO_URL || null,
    bannerUrl: process.env.STORE_BANNER_URL || null,
  },

  channels: {
    loja: process.env.CHANNEL_LOJA,
    logs: process.env.CHANNEL_LOGS,
    pagamentos: process.env.CHANNEL_PAGAMENTOS,
    tickets: process.env.CHANNEL_TICKETS,
    categoryTickets: process.env.CATEGORY_TICKETS,
  },

  roles: {
    admin: process.env.ROLE_ADMIN,
    cliente: process.env.ROLE_CLIENTE,
  },

  pix: {
    chave: process.env.PIX_CHAVE,
    nome: process.env.PIX_NOME,
    cidade: process.env.PIX_CIDADE,
  },

  payment: {
    expiryMinutes: parseInt(process.env.PAYMENT_EXPIRY_MINUTES) || 30,
    maxCartItems: parseInt(process.env.MAX_CART_ITEMS) || 10,
  },

  antiSpam: {
    cooldown: parseInt(process.env.ANTI_SPAM_COOLDOWN) || 5000,
  },

  colors: {
    primary: 0x5865F2,
    success: 0x57F287,
    warning: 0xFEE75C,
    danger: 0xED4245,
    info: 0x5865F2,
    gold: 0xFFD700,
  },

  emojis: {
    cart: '🛒',
    money: '💰',
    check: '✅',
    cross: '❌',
    star: '⭐',
    fire: '🔥',
    gift: '🎁',
    lock: '🔒',
    key: '🔑',
    ticket: '🎫',
    pix: '💸',
    mp: '💳',
    warning: '⚠️',
    info: 'ℹ️',
    trash: '🗑️',
    edit: '✏️',
    add: '➕',
    stock: '📦',
    user: '👤',
    ban: '🔨',
    logs: '📋',
    arrow: '➡️',
    clock: '⏰',
  },
};
