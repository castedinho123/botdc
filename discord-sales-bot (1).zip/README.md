# 🛒 Discord Sales Bot — Documentação Completa

Bot de vendas profissional para Discord com Pix, Mercado Pago, entrega automática e banco de dados Supabase.

---

## 📁 Estrutura de Arquivos

```
discord-sales-bot/
├── src/
│   ├── index.js                        ← Entrada principal do bot
│   ├── deploy-commands.js              ← Registra slash commands
│   ├── commands/
│   │   ├── admin/
│   │   │   └── index.js               ← /produto /estoque /cupom /usuario /loja
│   │   └── shop/
│   │       ├── loja.js                ← UI da loja (embeds, botões, dropdowns)
│   │       └── payment.js             ← Fluxo de pagamento Pix e MP
│   ├── handlers/
│   │   ├── interactionHandler.js      ← Roteador de botões/selects/modais
│   │   └── cronHandler.js             ← Jobs automáticos (expiração, estoque)
│   ├── services/
│   │   ├── database.js                ← Supabase (produtos, pedidos, cupons...)
│   │   ├── pix.js                     ← Gerador de Pix nativo (QR + copia e cola)
│   │   ├── mercadopago.js             ← Integração Mercado Pago
│   │   ├── delivery.js                ← Entrega automática (DM ou ticket)
│   │   └── logger.js                  ← Logs em canal do Discord
│   └── utils/
│       ├── cart.js                    ← Carrinho em memória por usuário
│       ├── embeds.js                  ← Fabrica de embeds padronizados
│       └── antiSpam.js                ← Cooldowns e proteção anti-fraude
├── config/
│   └── index.js                       ← Todas as configurações centralizadas
├── supabase_schema.sql                ← Schema completo do banco de dados
├── .env.example                       ← Modelo de variaveis de ambiente
└── package.json
```

---

## Instalação Passo a Passo

### 1. Pre-requisitos
- Node.js 18+
- Conta no Supabase (https://supabase.com)
- Bot criado no Discord Developer Portal
- Conta no Mercado Pago Developers (opcional)

### 2. Instalar dependencias
```bash
npm install
```

### 3. Configurar variaveis de ambiente
```bash
cp .env.example .env
```
Edite o `.env` com suas credenciais.

### 4. Criar tabelas no Supabase
1. Acesse seu projeto no Supabase
2. Va em SQL Editor
3. Cole todo o conteudo de `supabase_schema.sql` e execute

### 5. Registrar slash commands
```bash
npm run deploy
```

### 6. Iniciar o bot
```bash
npm start
```

---

## Variaveis de Ambiente (.env)

```
DISCORD_TOKEN          Token do bot
CLIENT_ID              ID da aplicacao Discord
GUILD_ID               ID do servidor Discord
SUPABASE_URL           URL do projeto Supabase
SUPABASE_SERVICE_KEY   Chave service_role do Supabase
MERCADOPAGO_ACCESS_TOKEN  Token do Mercado Pago (opcional)
PIX_CHAVE              Sua chave Pix
PIX_NOME               Nome que aparece no Pix
PIX_CIDADE             Cidade que aparece no Pix
STORE_NAME             Nome da sua loja
STORE_COLOR            Cor hex dos embeds (ex: #5865F2)
CHANNEL_LOJA           ID do canal da loja
CHANNEL_LOGS           ID do canal de logs
CATEGORY_TICKETS       ID da categoria de tickets
ROLE_ADMIN             ID do cargo de administrador
ROLE_CLIENTE           ID do cargo dado apos compra
PAYMENT_EXPIRY_MINUTES Minutos ate o pedido expirar (padrao: 30)
```

---

## Comandos de Admin

### Produtos
```
/produto criar   — Cria novo produto
/produto editar  — Edita um produto pelo ID
/produto deletar — Remove um produto
/produto listar  — Lista todos com IDs
```

### Estoque
```
/estoque adicionar <produto_id> <itens separados por |>
/estoque ver      <produto_id>
/estoque definir  <produto_id> <quantidade>
```
Exemplo:
```
/estoque adicionar produto_id:abc123 itens:KEY-AAA|KEY-BBB|KEY-CCC
```

### Cupons
```
/cupom criar     <codigo> <desconto%> [max_usos]
/cupom listar
/cupom desativar <codigo>
```

### Usuarios
```
/usuario bloquear    <usuario> [motivo]
/usuario desbloquear <usuario>
/usuario historico   <usuario>
```

### Loja
```
/loja painel                          — Publica painel no canal atual
/loja pedido <id>                     — Detalhes de um pedido
/loja confirmar_pagamento <pedido_id> — Confirma pagamento manualmente
```

---

## Fluxo de Compra (Cliente)

1. Ve o painel com dropdown de produtos
2. Seleciona produto, ve detalhes com imagem e preco
3. Escolhe quantidade e clica em Comprar ou Adicionar ao Carrinho
4. Aplica cupom de desconto (opcional)
5. Escolhe Pix ou Mercado Pago
6. Recebe QR Code + codigo copia e cola
7. Pagamento verificado automaticamente a cada 15 segundos
8. Produto entregue no privado (DM) ou ticket automaticamente
9. Cargo de cliente adicionado automaticamente

---

## Tipos de Produto

- digital  — Keys, contas, links (entregues do estoque)
- cargo    — Cargo do Discord (adicionado automaticamente)
- manual   — Produtos fisicos ou servicos (envia mensagem de contato)

---

## Pagamentos

### Pix Nativo
- Gera payload EMV padrao Banco Central
- QR Code gerado localmente sem APIs externas
- Verificacao automatica via polling ou manual com /loja confirmar_pagamento

### Mercado Pago
- Cria pagamento Pix na API do MP
- Verificacao 100% automatica via polling a cada 15 segundos
- Entrega sem nenhuma acao manual

---

## Jobs Automaticos (Cron)

- A cada 5 min  — Expira pedidos vencidos
- A cada 1 hora — Alerta de estoque baixo no canal de logs

---

## Gerenciando pelo Supabase

No painel Table Editor voce pode editar diretamente:

- produtos      — Preco, imagens, descricao, ativar/desativar
- estoque_itens — Adicionar itens individualmente
- pedidos       — Acompanhar e alterar status
- cupons        — Criar e desativar
- usuarios      — Bloquear/desbloquear
- avaliacoes    — Ver feedbacks

---

## Duvidas Frequentes

O bot nao responde aos botoes?
Verifique o DISCORD_TOKEN e as permissoes Send Messages e Use Application Commands.

O Pix nao e verificado automaticamente?
O Pix nativo nao tem webhook — use /loja confirmar_pagamento, ou use Mercado Pago para verificacao automatica.

Erro de permission denied no Supabase?
Use a SUPABASE_SERVICE_KEY (service_role), nao a anon key.

Como adicionar imagem ao produto?
Use /produto criar imagem_url:https://... com URL direta (Discord CDN ou Imgur).
