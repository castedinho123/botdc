-- =============================================
-- SCHEMA SUPABASE — BOT DE VENDAS DISCORD
-- Execute no SQL Editor do Supabase
-- =============================================

-- PRODUTOS
CREATE TABLE IF NOT EXISTS produtos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nome TEXT NOT NULL,
  descricao TEXT,
  descricao_curta TEXT,
  preco NUMERIC(10,2) NOT NULL,
  estoque INTEGER DEFAULT 0,
  tipo TEXT DEFAULT 'digital' CHECK (tipo IN ('digital','cargo','manual')),
  emoji TEXT DEFAULT '📦',
  imagem_url TEXT,
  thumbnail_url TEXT,
  cargo_id TEXT,
  ativo BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ESTOQUE ITENS (keys, contas, links)
CREATE TABLE IF NOT EXISTS estoque_itens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  produto_id UUID REFERENCES produtos(id) ON DELETE CASCADE,
  conteudo TEXT NOT NULL,
  usado BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- PEDIDOS
CREATE TABLE IF NOT EXISTS pedidos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  usuario_id TEXT NOT NULL,
  usuario_tag TEXT,
  valor NUMERIC(10,2),
  desconto NUMERIC(10,2) DEFAULT 0,
  status TEXT DEFAULT 'pendente' CHECK (status IN ('pendente','pago','entregue','cancelado','expirado')),
  metodo TEXT,
  payment_id TEXT,
  expires_at TIMESTAMPTZ,
  entregue_em TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ITENS DO PEDIDO
CREATE TABLE IF NOT EXISTS itens_pedido (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pedido_id UUID REFERENCES pedidos(id) ON DELETE CASCADE,
  produto_id UUID REFERENCES produtos(id),
  nome_produto TEXT,
  preco_unitario NUMERIC(10,2),
  quantidade INTEGER DEFAULT 1
);

-- CUPONS
CREATE TABLE IF NOT EXISTS cupons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  codigo TEXT UNIQUE NOT NULL,
  desconto INTEGER NOT NULL CHECK (desconto BETWEEN 1 AND 100),
  usos_maximos INTEGER,
  usos_atuais INTEGER DEFAULT 0,
  ativo BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- USUARIOS
CREATE TABLE IF NOT EXISTS usuarios (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  discord_id TEXT UNIQUE NOT NULL,
  bloqueado BOOLEAN DEFAULT FALSE,
  motivo_bloqueio TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- TICKETS
CREATE TABLE IF NOT EXISTS tickets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pedido_id UUID REFERENCES pedidos(id),
  usuario_id TEXT NOT NULL,
  canal_id TEXT,
  status TEXT DEFAULT 'aberto',
  fechado_em TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- AVALIACOES
CREATE TABLE IF NOT EXISTS avaliacoes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  usuario_id TEXT NOT NULL,
  usuario_tag TEXT,
  estrelas INTEGER DEFAULT 5,
  comentario TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- FUNCAO: decrementa estoque atomicamente
-- =============================================
CREATE OR REPLACE FUNCTION decrementar_estoque(produto_id UUID, qtd INTEGER)
RETURNS VOID AS $$
BEGIN
  UPDATE produtos
  SET estoque = GREATEST(0, estoque - qtd),
      updated_at = NOW()
  WHERE id = produto_id;
END;
$$ LANGUAGE plpgsql;

-- =============================================
-- ROW LEVEL SECURITY
-- =============================================
ALTER TABLE produtos ENABLE ROW LEVEL SECURITY;
ALTER TABLE pedidos ENABLE ROW LEVEL SECURITY;
ALTER TABLE itens_pedido ENABLE ROW LEVEL SECURITY;
ALTER TABLE cupons ENABLE ROW LEVEL SECURITY;
ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE avaliacoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE estoque_itens ENABLE ROW LEVEL SECURITY;

CREATE POLICY "service_role full access produtos"     ON produtos        FOR ALL USING (true);
CREATE POLICY "service_role full access pedidos"      ON pedidos         FOR ALL USING (true);
CREATE POLICY "service_role full access itens"        ON itens_pedido    FOR ALL USING (true);
CREATE POLICY "service_role full access cupons"       ON cupons          FOR ALL USING (true);
CREATE POLICY "service_role full access usuarios"     ON usuarios        FOR ALL USING (true);
CREATE POLICY "service_role full access tickets"      ON tickets         FOR ALL USING (true);
CREATE POLICY "service_role full access avaliacoes"   ON avaliacoes      FOR ALL USING (true);
CREATE POLICY "service_role full access estoque"      ON estoque_itens   FOR ALL USING (true);

-- =============================================
-- INDICES
-- =============================================
CREATE INDEX IF NOT EXISTS idx_pedidos_usuario    ON pedidos(usuario_id);
CREATE INDEX IF NOT EXISTS idx_pedidos_status     ON pedidos(status);
CREATE INDEX IF NOT EXISTS idx_pedidos_payment    ON pedidos(payment_id);
CREATE INDEX IF NOT EXISTS idx_estoque_produto    ON estoque_itens(produto_id, usado);
CREATE INDEX IF NOT EXISTS idx_usuarios_discord   ON usuarios(discord_id);
