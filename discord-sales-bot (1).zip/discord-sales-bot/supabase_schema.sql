-- ============================================================
-- DISCORD SALES BOT — SCHEMA SUPABASE
-- Execute este SQL no SQL Editor do seu projeto Supabase
-- ============================================================

-- Extensão para UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- TABELA: produtos
-- ============================================================
CREATE TABLE IF NOT EXISTS produtos (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nome        TEXT NOT NULL,
  descricao   TEXT,
  descricao_curta TEXT,
  preco       NUMERIC(10,2) NOT NULL DEFAULT 0,
  estoque     INTEGER NOT NULL DEFAULT 0,
  tipo        TEXT NOT NULL DEFAULT 'digital', -- digital | cargo | manual
  emoji       TEXT DEFAULT '📦',
  imagem_url  TEXT,
  thumbnail_url TEXT,
  cargo_id    TEXT,
  ativo       BOOLEAN NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABELA: estoque_itens (keys, contas, links)
-- ============================================================
CREATE TABLE IF NOT EXISTS estoque_itens (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  produto_id  UUID NOT NULL REFERENCES produtos(id) ON DELETE CASCADE,
  conteudo    TEXT NOT NULL,
  usado       BOOLEAN NOT NULL DEFAULT FALSE,
  usado_em    TIMESTAMPTZ,
  pedido_id   UUID,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_estoque_produto ON estoque_itens(produto_id, usado);

-- ============================================================
-- TABELA: pedidos
-- ============================================================
CREATE TABLE IF NOT EXISTS pedidos (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  usuario_id    TEXT NOT NULL,
  usuario_tag   TEXT,
  valor         NUMERIC(10,2) NOT NULL DEFAULT 0,
  desconto      NUMERIC(10,2) DEFAULT 0,
  status        TEXT NOT NULL DEFAULT 'pendente', -- pendente | pago | entregue | cancelado | expirado
  metodo        TEXT, -- pix_nativo | mercado_pago
  payment_id    TEXT,
  cupom_id      UUID,
  expires_at    TIMESTAMPTZ,
  entregue_em   TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_pedidos_usuario ON pedidos(usuario_id);
CREATE INDEX IF NOT EXISTS idx_pedidos_status  ON pedidos(status);
CREATE INDEX IF NOT EXISTS idx_pedidos_payment ON pedidos(payment_id);

-- ============================================================
-- TABELA: itens_pedido
-- ============================================================
CREATE TABLE IF NOT EXISTS itens_pedido (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  pedido_id       UUID NOT NULL REFERENCES pedidos(id) ON DELETE CASCADE,
  produto_id      UUID REFERENCES produtos(id),
  nome_produto    TEXT NOT NULL,
  preco_unitario  NUMERIC(10,2) NOT NULL,
  quantidade      INTEGER NOT NULL DEFAULT 1,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_itens_pedido ON itens_pedido(pedido_id);

-- ============================================================
-- TABELA: cupons
-- ============================================================
CREATE TABLE IF NOT EXISTS cupons (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  codigo        TEXT NOT NULL UNIQUE,
  desconto      INTEGER NOT NULL DEFAULT 10, -- percentual
  usos_maximos  INTEGER, -- null = ilimitado
  usos_atuais   INTEGER NOT NULL DEFAULT 0,
  ativo         BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABELA: usuarios
-- ============================================================
CREATE TABLE IF NOT EXISTS usuarios (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  discord_id      TEXT NOT NULL UNIQUE,
  bloqueado       BOOLEAN NOT NULL DEFAULT FALSE,
  motivo_bloqueio TEXT,
  total_gasto     NUMERIC(10,2) DEFAULT 0,
  total_pedidos   INTEGER DEFAULT 0,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_usuarios_discord ON usuarios(discord_id);

-- ============================================================
-- TABELA: tickets
-- ============================================================
CREATE TABLE IF NOT EXISTS tickets (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  canal_id    TEXT NOT NULL,
  usuario_id  TEXT NOT NULL,
  pedido_id   UUID REFERENCES pedidos(id),
  status      TEXT NOT NULL DEFAULT 'aberto', -- aberto | fechado
  fechado_em  TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TABELA: avaliacoes
-- ============================================================
CREATE TABLE IF NOT EXISTS avaliacoes (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  usuario_id  TEXT NOT NULL,
  usuario_tag TEXT,
  estrelas    INTEGER NOT NULL DEFAULT 5,
  comentario  TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- FUNÇÃO: decrementar_estoque (atomic)
-- ============================================================
CREATE OR REPLACE FUNCTION decrementar_estoque(produto_id UUID, qtd INTEGER)
RETURNS VOID AS $$
BEGIN
  UPDATE produtos
  SET estoque = GREATEST(0, estoque - qtd),
      updated_at = NOW()
  WHERE id = produto_id;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- FUNÇÃO: incrementar_total_usuario (após compra)
-- ============================================================
CREATE OR REPLACE FUNCTION incrementar_total_usuario(p_discord_id TEXT, p_valor NUMERIC)
RETURNS VOID AS $$
BEGIN
  INSERT INTO usuarios (discord_id, total_gasto, total_pedidos)
  VALUES (p_discord_id, p_valor, 1)
  ON CONFLICT (discord_id) DO UPDATE
    SET total_gasto   = usuarios.total_gasto + p_valor,
        total_pedidos = usuarios.total_pedidos + 1,
        updated_at    = NOW();
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- ROW LEVEL SECURITY (RLS)
-- Permite service_role ler/escrever tudo
-- ============================================================
ALTER TABLE produtos       ENABLE ROW LEVEL SECURITY;
ALTER TABLE estoque_itens  ENABLE ROW LEVEL SECURITY;
ALTER TABLE pedidos        ENABLE ROW LEVEL SECURITY;
ALTER TABLE itens_pedido   ENABLE ROW LEVEL SECURITY;
ALTER TABLE cupons         ENABLE ROW LEVEL SECURITY;
ALTER TABLE usuarios       ENABLE ROW LEVEL SECURITY;
ALTER TABLE tickets        ENABLE ROW LEVEL SECURITY;
ALTER TABLE avaliacoes     ENABLE ROW LEVEL SECURITY;

-- Policies para service_role (o bot usa a service key)
CREATE POLICY "service_role_all" ON produtos       FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "service_role_all" ON estoque_itens  FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "service_role_all" ON pedidos        FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "service_role_all" ON itens_pedido   FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "service_role_all" ON cupons         FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "service_role_all" ON usuarios       FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "service_role_all" ON tickets        FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "service_role_all" ON avaliacoes     FOR ALL USING (auth.role() = 'service_role');

-- ============================================================
-- DADOS INICIAIS DE EXEMPLO (opcional — remova se quiser)
-- ============================================================
INSERT INTO produtos (nome, descricao, descricao_curta, preco, estoque, tipo, emoji)
VALUES
  ('Netflix Premium', 'Conta Netflix Premium 4K UHD, acesso completo por 30 dias.', 'Netflix 4K • 30 dias', 25.90, 50, 'digital', '🎬'),
  ('Spotify Premium', 'Conta Spotify Premium individual, sem anúncios.', 'Spotify sem anúncios', 12.90, 30, 'digital', '🎵'),
  ('VIP Discord', 'Cargo VIP exclusivo no servidor com acesso a canais especiais.', 'Cargo VIP exclusivo', 9.90, 999, 'cargo', '👑')
ON CONFLICT DO NOTHING;

INSERT INTO cupons (codigo, desconto, usos_maximos, usos_atuais)
VALUES ('BEMVINDO', 10, 100, 0)
ON CONFLICT DO NOTHING;
