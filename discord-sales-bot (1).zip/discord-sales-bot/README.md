# 🛒 Discord Sales Bot — Bot de Vendas Profissional

Bot de vendas completo para Discord com Pix, Mercado Pago, estoque automático e entrega digital, integrado ao **Supabase**.

---

## 📁 Estrutura de Arquivos

```
discord-sales-bot/
├── src/
│   ├── index.js                    ← Entrada principal do bot
│   ├── deploy-commands.js          ← Registra slash commands
│   ├── commands/
│   │   ├── admin/
│   │   │   └── index.js            ← /produto, /estoque, /cupom, /usuario, /loja
│   │   └── shop/
│   │       ├── loja.js             ← UI da loja (embeds + botões + dropdowns)
│   │       └── payment.js          ← Checkout Pix e Mercado Pago
│   ├── handlers/
│   │   ├── interactionHandler.js   ← Roteador de botões/selects/modals
│   │   └── cronHandler.js          ← Jobs automáticos (expirar pedidos, alertas)
│   ├── services/
│   │   ├── database.js             ← Todas as queries Supabase
│   │   ├── pix.js                  ← Geração de QR Code Pix nativo
│   │   ├── mercadopago.js          ← Integração Mercado Pago
│   │   ├── delivery.js             ← Entrega automática (DM ou ticket)
│   │   └── logger.js               ← Logs em canal Discord
│   └── utils/
│       ├── embeds.js               ← Embeds bonitos reutilizáveis
│       ├── cart.js                 ← Carrinho em memória
│       └── antiSpam.js             ← Anti-spam e anti-fraude
├── config/
│   └── index.js                    ← Configurações centrais
├── supabase_schema.sql             ← Schema completo do banco de dados
├── .env.example                    ← Modelo de variáveis de ambiente
└── package.json
```

---

## ⚡ Instalação Rápida

### 1. Pré-requisitos
- Node.js 18+
- Conta no [Supabase](https://supabase.com) (gratuito)
- Bot criado no [Discord Developer Portal](https://discord.com/developers/applications)
- Conta no [Mercado Pago](https://www.mercadopago.com.br) (opcional)

### 2. Clone e instale dependências
```bash
git clone <seu-repo>
cd discord-sales-bot
npm install
```

### 3. Configure o `.env`
```bash
cp .env.example .env
```
Preencha todas as variáveis do `.env` (veja seção abaixo).

### 4. Configure o Supabase
1. Crie um projeto em [supabase.com](https://supabase.com)
2. Vá em **SQL Editor** → **New Query**
3. Cole todo o conteúdo de `supabase_schema.sql` e clique em **Run**
4. Copie a **URL** e as **chaves** em **Settings → API**

### 5. Crie o Bot Discord
1. Acesse [discord.com/developers/applications](https://discord.com/developers/applications)
2. Crie uma nova aplicação → vá em **Bot**
3. Copie o **Token**
4. Em **OAuth2 → URL Generator**, marque: `bot`, `applications.commands`
5. Permissões necessárias: `Send Messages`, `Embed Links`, `Attach Files`, `Manage Channels`, `Manage Roles`, `Read Message History`
6. Use o link gerado para convidar o bot ao servidor

### 6. Registre os slash commands
```bash
npm run deploy
```

### 7. Inicie o bot
```bash
npm start
# ou em desenvolvimento:
npm run dev
```

---

## 🔧 Variáveis de Ambiente (.env)

| Variável | Descrição | Obrigatório |
|---|---|---|
| `DISCORD_TOKEN` | Token do bot | ✅ |
| `CLIENT_ID` | ID da aplicação Discord | ✅ |
| `GUILD_ID` | ID do seu servidor Discord | ✅ |
| `SUPABASE_URL` | URL do projeto Supabase | ✅ |
| `SUPABASE_SERVICE_KEY` | Service Role Key do Supabase | ✅ |
| `MERCADOPAGO_ACCESS_TOKEN` | Access Token do Mercado Pago | ⚡ Pix MP |
| `PIX_CHAVE` | Sua chave Pix (CPF/email/telefone) | ⚡ Pix nativo |
| `PIX_NOME` | Nome do recebedor Pix | ⚡ Pix nativo |
| `PIX_CIDADE` | Cidade do recebedor Pix | ⚡ Pix nativo |
| `CHANNEL_LOJA` | ID do canal onde ficará o painel | ✅ |
| `CHANNEL_LOGS` | ID do canal de logs | ✅ |
| `CATEGORY_TICKETS` | ID da categoria de tickets | ✅ |
| `ROLE_ADMIN` | ID do cargo de admin | ✅ |
| `ROLE_CLIENTE` | ID do cargo dado após compra | ⭕ Opcional |
| `STORE_NAME` | Nome da sua loja | ✅ |
| `STORE_COLOR` | Cor hex dos embeds | ⭕ Opcional |
| `STORE_LOGO_URL` | URL do logo da loja | ⭕ Opcional |

---

## 🎮 Comandos Disponíveis

### 🛍️ Loja (usuários)
Todos os comandos de compra são feitos via **botões e dropdowns** no painel da loja.

### ⚙️ Administração (apenas admins)

#### Gerenciar Produtos
```
/produto criar   nome:Netflix preco:25.90 descricao:Conta 4K tipo:digital emoji:🎬
/produto editar  id:xxxx nome:Novo Nome preco:19.90
/produto deletar id:xxxx
/produto listar
```

#### Gerenciar Estoque
```
/estoque adicionar produto_id:xxxx itens:key1|key2|key3|key4
/estoque ver      produto_id:xxxx
/estoque definir  produto_id:xxxx quantidade:100
```

#### Gerenciar Cupons
```
/cupom criar    codigo:PROMO10 desconto:10 usos:50
/cupom listar
/cupom desativar codigo:PROMO10
```

#### Gerenciar Usuários
```
/usuario bloquear   usuario:@user motivo:Fraude
/usuario desbloquear usuario:@user
/usuario historico   usuario:@user
```

#### Painel da Loja
```
/loja painel                      ← Publica o painel no canal atual
/loja pedido id:xxxx              ← Ver detalhes de um pedido
/loja confirmar_pagamento pedido_id:xxxx  ← Confirmar manualmente
```

---

## 🗄️ Gerenciar Estoque no Supabase

Você pode editar o estoque diretamente no painel do Supabase:

1. Acesse seu projeto → **Table Editor**
2. Selecione a tabela **`produtos`** para ver/editar estoque
3. Selecione **`estoque_itens`** para ver keys/contas individuais
4. Use filtros para buscar por produto

### Adicionar itens em massa via SQL:
```sql
INSERT INTO estoque_itens (produto_id, conteudo)
VALUES
  ('seu-produto-uuid', 'user1@email.com:senha123'),
  ('seu-produto-uuid', 'user2@email.com:senha456'),
  ('seu-produto-uuid', 'CHAVE-XXXX-YYYY-ZZZZ');

-- Atualiza o contador de estoque
UPDATE produtos
SET estoque = (SELECT COUNT(*) FROM estoque_itens WHERE produto_id = 'seu-produto-uuid' AND usado = false)
WHERE id = 'seu-produto-uuid';
```

---

## 🔄 Fluxo de Compra

```
Cliente vê painel → Seleciona produto (dropdown)
    → Ver detalhes → Seleciona quantidade
    → Adicionar ao carrinho / Comprar agora
    → Revisar carrinho → Aplicar cupom (opcional)
    → Escolher pagamento (Pix / Mercado Pago)
    → QR Code + Copia e Cola gerado
    → Verificação automática a cada 15s
    → Pagamento aprovado → Entrega automática (DM ou ticket)
    → Cargo dado + Log registrado
```

---

## 📦 Tipos de Produto

| Tipo | Como funciona | Entrega |
|---|---|---|
| `digital` | Retira item da tabela `estoque_itens` | Envia no DM/ticket com spoiler `\|\|conteudo\|\|` |
| `cargo` | Adiciona cargo definido em `cargo_id` | Confirma que o cargo foi dado |
| `manual` | Sem entrega automática | Notifica equipe para entrar em contato |

---

## 🛡️ Segurança

- **Anti-spam**: cooldown de 5s por usuário por ação
- **Anti-fraude**: múltiplos pagamentos falhos registrados
- **Bloqueio de usuários**: via `/usuario bloquear`
- **RLS no Supabase**: apenas a `service_role` key tem acesso total
- **Pedidos expiram**: automaticamente após o tempo configurado

---

## 🚀 Produção (VPS/Servidor)

### Com PM2 (recomendado):
```bash
npm install -g pm2
pm2 start src/index.js --name "sales-bot"
pm2 save
pm2 startup
```

### Com Docker:
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --production
COPY . .
CMD ["node", "src/index.js"]
```

---

## 🆘 Suporte e Dúvidas

- Verifique os logs no canal configurado em `CHANNEL_LOGS`
- Erros críticos são logados automaticamente com stack trace
- Para problemas de Pix: confirme que a chave está correta e o formato do payload
- Para Mercado Pago: verifique se o `ACCESS_TOKEN` é de produção (não sandbox)

---

## 📝 Licença

Projeto de uso privado. Não redistribua sem autorização.
