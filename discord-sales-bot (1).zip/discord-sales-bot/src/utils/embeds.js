const { EmbedBuilder } = require('discord.js');
const config = require('../../config');

const E = config.emojis;
const C = config.colors;
const S = config.store;

function base() {
  const e = new EmbedBuilder().setColor(S.color || C.primary);
  if (S.logoUrl) e.setThumbnail(S.logoUrl);
  return e;
}

function loja() {
  const e = base()
    .setTitle(`${E.fire} ${S.name} — Loja Oficial`)
    .setDescription('Bem-vindo! Navegue pelos produtos abaixo e clique para comprar.')
    .setTimestamp()
    .setFooter({ text: `${S.name} • Pagamentos seguros via Pix & Mercado Pago` });
  if (S.bannerUrl) e.setImage(S.bannerUrl);
  return e;
}

function produto(p) {
  const e = base()
    .setTitle(`${p.emoji || '📦'} ${p.nome}`)
    .setDescription(p.descricao || 'Sem descrição.')
    .addFields(
      { name: `${E.money} Preço`, value: `**R$ ${p.preco.toFixed(2)}**`, inline: true },
      { name: `${E.stock} Estoque`, value: p.estoque > 0 ? `${p.estoque} unidade(s)` : '❌ Esgotado', inline: true },
      { name: `${E.info} Tipo`, value: p.tipo === 'digital' ? '💾 Digital' : p.tipo === 'cargo' ? '👑 Cargo' : '📩 Manual', inline: true }
    )
    .setTimestamp()
    .setFooter({ text: `${S.name} • Clique em Comprar para adquirir` });
  if (p.imagem_url) e.setImage(p.imagem_url);
  if (p.thumbnail_url) e.setThumbnail(p.thumbnail_url);
  return e;
}

function carrinho(itens, totais, cupom = null) {
  const linhas = itens.map(i =>
    `${i.emoji} **${i.nome}** x${i.quantidade} — R$ ${(i.preco * i.quantidade).toFixed(2)}`
  ).join('\n') || '*Carrinho vazio*';

  const e = base()
    .setTitle(`${E.cart} Seu Carrinho`)
    .setDescription(linhas)
    .addFields(
      { name: '💲 Subtotal', value: `R$ ${totais.subtotal.toFixed(2)}`, inline: true }
    );

  if (cupom) {
    e.addFields({ name: '🏷️ Desconto', value: `- R$ ${totais.desconto.toFixed(2)} (${cupom.desconto}%)`, inline: true });
  }

  e.addFields({ name: '✅ Total', value: `**R$ ${totais.total.toFixed(2)}**`, inline: true })
    .setFooter({ text: 'Escolha o método de pagamento abaixo' })
    .setTimestamp();

  return e;
}

function pagamentoPix(pedidoId, valor, expiresAt) {
  return base()
    .setColor(C.success)
    .setTitle(`${E.pix} Pagamento via Pix`)
    .setDescription('Escaneie o QR Code ou copie o código Pix abaixo para efetuar o pagamento.')
    .addFields(
      { name: '💰 Valor', value: `**R$ ${valor.toFixed(2)}**`, inline: true },
      { name: '⏰ Expira em', value: `<t:${Math.floor(expiresAt / 1000)}:R>`, inline: true },
      { name: '🆔 Pedido', value: `#${pedidoId.substring(0, 8).toUpperCase()}`, inline: true }
    )
    .setFooter({ text: 'Pagamento verificado automaticamente • Não feche este canal' })
    .setTimestamp();
}

function pedidoConfirmado(pedidoId, usuario, valor) {
  return base()
    .setColor(C.success)
    .setTitle(`${E.check} Pagamento Confirmado!`)
    .setDescription(`Seu pagamento de **R$ ${valor.toFixed(2)}** foi aprovado!\nSua entrega está sendo processada...`)
    .addFields(
      { name: '🆔 Pedido', value: `#${pedidoId.substring(0, 8).toUpperCase()}`, inline: true },
      { name: '👤 Comprador', value: `<@${usuario}>`, inline: true }
    )
    .setTimestamp();
}

function erro(titulo, descricao) {
  return new EmbedBuilder()
    .setColor(C.danger)
    .setTitle(`${E.cross} ${titulo}`)
    .setDescription(descricao)
    .setTimestamp();
}

function sucesso(titulo, descricao) {
  return new EmbedBuilder()
    .setColor(C.success)
    .setTitle(`${E.check} ${titulo}`)
    .setDescription(descricao)
    .setTimestamp();
}

function aviso(titulo, descricao) {
  return new EmbedBuilder()
    .setColor(C.warning)
    .setTitle(`${E.warning} ${titulo}`)
    .setDescription(descricao)
    .setTimestamp();
}

module.exports = { loja, produto, carrinho, pagamentoPix, pedidoConfirmado, erro, sucesso, aviso };
