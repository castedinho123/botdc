const config = require('../../config');
const db = require('../services/database');

// Map de cooldowns em memória
const cooldowns = new Map();
const tentativasFraude = new Map();

/**
 * Verifica se o usuário está em cooldown
 */
function verificarCooldown(userId, acao = 'geral') {
  const chave = `${userId}-${acao}`;
  const agora = Date.now();
  const ultimo = cooldowns.get(chave) || 0;

  if (agora - ultimo < config.antiSpam.cooldown) {
    return { bloqueado: true, restante: Math.ceil((config.antiSpam.cooldown - (agora - ultimo)) / 1000) };
  }
  cooldowns.set(chave, agora);
  return { bloqueado: false };
}

/**
 * Registra tentativa de fraude (múltiplos pagamentos falhos)
 */
function registrarFraude(userId) {
  const tentativas = (tentativasFraude.get(userId) || 0) + 1;
  tentativasFraude.set(userId, tentativas);
  return tentativas;
}

/**
 * Verifica se usuário está bloqueado (DB + memória)
 */
async function verificarBloqueio(userId) {
  return await db.usuarios.estaBloqueado(userId);
}

/**
 * Limpa cooldown de um usuário
 */
function limparCooldown(userId) {
  for (const [chave] of cooldowns) {
    if (chave.startsWith(userId)) cooldowns.delete(chave);
  }
}

module.exports = { verificarCooldown, registrarFraude, verificarBloqueio, limparCooldown };
