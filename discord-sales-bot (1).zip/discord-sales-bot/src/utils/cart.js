const config = require('../../config');

// carrinho[userId] = [{ produtoId, nome, preco, quantidade, emoji }]
const carrinhos = new Map();

function obter(userId) {
  return carrinhos.get(userId) || [];
}

function adicionar(userId, produto, quantidade = 1) {
  const carrinho = obter(userId);
  const total = carrinho.reduce((acc, i) => acc + i.quantidade, 0);
  if (total + quantidade > config.payment.maxCartItems) {
    return { sucesso: false, motivo: `Limite de ${config.payment.maxCartItems} itens no carrinho atingido.` };
  }
  if (produto.estoque < quantidade) {
    return { sucesso: false, motivo: 'Estoque insuficiente para essa quantidade.' };
  }

  const existente = carrinho.find(i => i.produtoId === produto.id);
  if (existente) {
    existente.quantidade += quantidade;
  } else {
    carrinho.push({
      produtoId: produto.id,
      nome: produto.nome,
      emoji: produto.emoji || '📦',
      preco: produto.preco,
      quantidade,
    });
  }
  carrinhos.set(userId, carrinho);
  return { sucesso: true };
}

function remover(userId, produtoId) {
  const carrinho = obter(userId).filter(i => i.produtoId !== produtoId);
  carrinhos.set(userId, carrinho);
}

function limpar(userId) {
  carrinhos.delete(userId);
}

function calcularTotal(userId, desconto = 0) {
  const carrinho = obter(userId);
  const subtotal = carrinho.reduce((acc, i) => acc + i.preco * i.quantidade, 0);
  const totalDesconto = subtotal * (desconto / 100);
  return { subtotal, desconto: totalDesconto, total: subtotal - totalDesconto };
}

function estaVazio(userId) {
  return obter(userId).length === 0;
}

module.exports = { obter, adicionar, remover, limpar, calcularTotal, estaVazio };
