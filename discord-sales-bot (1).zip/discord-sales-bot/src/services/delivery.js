const { EmbedBuilder, ChannelType, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../config');
const db = require('./database');
const logger = require('./logger');

let client = null;
function setClient(c) { client = c; }

/**
 * Entrega produtos após pagamento confirmado
 */
async function entregarPedido(pedidoId, guild) {
  const pedido = await db.pedidos.buscarPorId(pedidoId);
  if (!pedido || pedido.status !== 'pago') return;

  const usuario = await guild.members.fetch(pedido.usuario_id).catch(() => null);
  if (!usuario) {
    await logger.enviarLog('erro', { Pedido: pedidoId, Erro: 'Usuário não encontrado no servidor' });
    return;
  }

  // Coleta os itens de todos os produtos do pedido
  const itensPedido = await db.pedidos.buscarPorId(pedidoId);
  const produtos_entregues = [];

  for (const item of itensPedido.itens_pedido || []) {
    const produto = await db.produtos.buscarPorId(item.produto_id);
    if (!produto) continue;

    let conteudoEntregue = [];

    if (produto.tipo === 'digital') {
      // Retira do estoque (keys/contas/links)
      const itens = await db.produtos.retirarItensEstoque(produto.id, item.quantidade);
      if (itens) conteudoEntregue = itens;
      else conteudoEntregue = ['⚠️ Estoque esgotado - entre em contato com o suporte'];
    } else if (produto.tipo === 'cargo') {
      // Entrega cargo
      if (produto.cargo_id) {
        await usuario.roles.add(produto.cargo_id).catch(() => {});
        conteudoEntregue = [`✅ Cargo <@&${produto.cargo_id}> adicionado!`];
      }
    } else if (produto.tipo === 'manual') {
      conteudoEntregue = ['📩 Produto manual - nossa equipe entrará em contato em breve.'];
    }

    produtos_entregues.push({
      nome: produto.nome,
      quantidade: item.quantidade,
      itens: conteudoEntregue,
    });
  }

  // Dar cargo de cliente
  if (config.roles.cliente) {
    await usuario.roles.add(config.roles.cliente).catch(() => {});
  }

  // Monta embed de entrega
  const embed = new EmbedBuilder()
    .setColor(config.colors.success)
    .setTitle(`✅ Pedido Entregue — ${config.store.name}`)
    .setDescription(`Obrigado pela sua compra, ${usuario}! 🎉\nSegue abaixo o conteúdo do seu pedido:`)
    .setTimestamp()
    .setFooter({ text: `Pedido #${pedidoId.substring(0, 8).toUpperCase()} • ${config.store.name}` });

  if (config.store.logoUrl) embed.setThumbnail(config.store.logoUrl);

  for (const prod of produtos_entregues) {
    const conteudo = prod.itens.map((item, i) =>
      prod.quantidade > 1 ? `\`${i + 1}.\` ||${item}||` : `||${item}||`
    ).join('\n');
    embed.addFields({
      name: `${config.emojis.gift} ${prod.nome} (x${prod.quantidade})`,
      value: conteudo || 'Nenhum item',
      inline: false,
    });
  }

  embed.addFields({
    name: '📝 Avaliação',
    value: 'Gostou do atendimento? Use `/avaliar` para deixar sua opinião!',
    inline: false,
  });

  // Tenta enviar no privado
  let enviouDM = false;
  try {
    await usuario.send({ embeds: [embed] });
    enviouDM = true;
  } catch {}

  // Se não conseguiu enviar DM, envia no ticket
  if (!enviouDM) {
    await enviarNoTicket(guild, usuario, pedidoId, embed);
  }

  // Atualiza status do pedido
  await db.pedidos.atualizar(pedidoId, { status: 'entregue', entregue_em: new Date().toISOString() });

  await logger.enviarLog('entrega', {
    '📦 Pedido': `#${pedidoId.substring(0, 8).toUpperCase()}`,
    '👤 Usuário': `${usuario.user.tag} (${usuario.id})`,
    '📬 Método': enviouDM ? 'DM' : 'Ticket',
    '🛒 Produtos': produtos_entregues.map(p => p.nome).join(', '),
  });
}

async function enviarNoTicket(guild, membro, pedidoId, embedEntrega) {
  const categoria = guild.channels.cache.get(config.channels.categoryTickets);

  const canal = await guild.channels.create({
    name: `entrega-${membro.user.username.toLowerCase()}-${pedidoId.substring(0, 6)}`,
    type: ChannelType.GuildText,
    parent: categoria?.id,
    permissionOverwrites: [
      { id: guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
      { id: membro.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
      { id: config.roles.admin, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
    ],
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`fechar_ticket_${canal.id}`)
      .setLabel('Fechar Ticket')
      .setEmoji('🔒')
      .setStyle(ButtonStyle.Danger)
  );

  await canal.send({
    content: `${membro} — Sua entrega está aqui! 🎁`,
    embeds: [embedEntrega],
    components: [row],
  });
}

module.exports = { setClient, entregarPedido };
