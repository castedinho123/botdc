const { createClient } = require('@supabase/supabase-js');
const config = require('../../config');

const supabase = createClient(config.supabase.url, config.supabase.serviceKey);

// ============================================================
// PRODUTOS
// ============================================================
const produtos = {
  async listar() {
    const { data, error } = await supabase
      .from('produtos')
      .select('*')
      .eq('ativo', true)
      .order('created_at', { ascending: true });
    if (error) throw error;
    return data;
  },

  async buscarPorId(id) {
    const { data, error } = await supabase
      .from('produtos')
      .select('*')
      .eq('id', id)
      .single();
    if (error) throw error;
    return data;
  },

  async criar(produto) {
    const { data, error } = await supabase
      .from('produtos')
      .insert([produto])
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async atualizar(id, atualizacoes) {
    const { data, error } = await supabase
      .from('produtos')
      .update({ ...atualizacoes, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async deletar(id) {
    const { error } = await supabase
      .from('produtos')
      .update({ ativo: false })
      .eq('id', id);
    if (error) throw error;
  },

  async atualizarEstoque(id, quantidade) {
    const { data, error } = await supabase.rpc('decrementar_estoque', {
      produto_id: id,
      qtd: quantidade,
    });
    if (error) throw error;
    return data;
  },

  async adicionarEstoque(id, itens) {
    // itens = array de strings (keys/contas/links)
    const inserts = itens.map(item => ({
      produto_id: id,
      conteudo: item,
      usado: false,
    }));
    const { error } = await supabase.from('estoque_itens').insert(inserts);
    if (error) throw error;
    // Atualiza count
    const { data: count } = await supabase
      .from('estoque_itens')
      .select('id', { count: 'exact' })
      .eq('produto_id', id)
      .eq('usado', false);
    await supabase
      .from('produtos')
      .update({ estoque: count?.length || 0 })
      .eq('id', id);
  },

  async retirarItensEstoque(produtoId, quantidade) {
    const { data, error } = await supabase
      .from('estoque_itens')
      .select('*')
      .eq('produto_id', produtoId)
      .eq('usado', false)
      .limit(quantidade);
    if (error) throw error;
    if (!data || data.length < quantidade) return null;
    const ids = data.map(i => i.id);
    await supabase.from('estoque_itens').update({ usado: true }).in('id', ids);
    await supabase.rpc('decrementar_estoque', { produto_id: produtoId, qtd: quantidade });
    return data.map(i => i.conteudo);
  },
};

// ============================================================
// PEDIDOS
// ============================================================
const pedidos = {
  async criar(pedido) {
    const { data, error } = await supabase
      .from('pedidos')
      .insert([pedido])
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async buscarPorId(id) {
    const { data, error } = await supabase
      .from('pedidos')
      .select('*, itens_pedido(*)')
      .eq('id', id)
      .single();
    if (error) throw error;
    return data;
  },

  async buscarPorPaymentId(paymentId) {
    const { data, error } = await supabase
      .from('pedidos')
      .select('*')
      .eq('payment_id', paymentId)
      .single();
    if (error) return null;
    return data;
  },

  async buscarPorUsuario(userId) {
    const { data, error } = await supabase
      .from('pedidos')
      .select('*, itens_pedido(*, produtos(nome))')
      .eq('usuario_id', userId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data;
  },

  async atualizar(id, atualizacoes) {
    const { data, error } = await supabase
      .from('pedidos')
      .update({ ...atualizacoes, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async criarItens(itensPedido) {
    const { error } = await supabase.from('itens_pedido').insert(itensPedido);
    if (error) throw error;
  },

  async buscarExpirados() {
    const limite = new Date(Date.now() - config.payment.expiryMinutes * 60 * 1000).toISOString();
    const { data, error } = await supabase
      .from('pedidos')
      .select('*')
      .eq('status', 'pendente')
      .lt('created_at', limite);
    if (error) throw error;
    return data || [];
  },
};

// ============================================================
// CUPONS
// ============================================================
const cupons = {
  async buscarPorCodigo(codigo) {
    const { data, error } = await supabase
      .from('cupons')
      .select('*')
      .eq('codigo', codigo.toUpperCase())
      .eq('ativo', true)
      .single();
    if (error) return null;
    return data;
  },

  async criar(cupon) {
    const { data, error } = await supabase
      .from('cupons')
      .insert([{ ...cupon, codigo: cupon.codigo.toUpperCase() }])
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async usar(id) {
    const { data } = await supabase
      .from('cupons')
      .select('usos_atuais, usos_maximos')
      .eq('id', id)
      .single();
    const novosUsos = (data?.usos_atuais || 0) + 1;
    await supabase
      .from('cupons')
      .update({
        usos_atuais: novosUsos,
        ativo: data?.usos_maximos ? novosUsos < data.usos_maximos : true,
      })
      .eq('id', id);
  },

  async listar() {
    const { data, error } = await supabase
      .from('cupons')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data;
  },
};

// ============================================================
// USUÁRIOS (BLOQUEADOS / HISTÓRICO)
// ============================================================
const usuarios = {
  async buscar(userId) {
    const { data } = await supabase
      .from('usuarios')
      .select('*')
      .eq('discord_id', userId)
      .single();
    return data;
  },

  async upsert(userId, dados = {}) {
    const { data, error } = await supabase
      .from('usuarios')
      .upsert({ discord_id: userId, ...dados }, { onConflict: 'discord_id' })
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async bloquear(userId, motivo) {
    return supabase
      .from('usuarios')
      .upsert({ discord_id: userId, bloqueado: true, motivo_bloqueio: motivo }, { onConflict: 'discord_id' });
  },

  async desbloquear(userId) {
    return supabase
      .from('usuarios')
      .update({ bloqueado: false, motivo_bloqueio: null })
      .eq('discord_id', userId);
  },

  async estaBloqueado(userId) {
    const { data } = await supabase
      .from('usuarios')
      .select('bloqueado')
      .eq('discord_id', userId)
      .single();
    return data?.bloqueado || false;
  },
};

// ============================================================
// TICKETS
// ============================================================
const tickets = {
  async criar(ticket) {
    const { data, error } = await supabase
      .from('tickets')
      .insert([ticket])
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async buscarPorPedido(pedidoId) {
    const { data } = await supabase
      .from('tickets')
      .select('*')
      .eq('pedido_id', pedidoId)
      .single();
    return data;
  },

  async fechar(id) {
    return supabase
      .from('tickets')
      .update({ status: 'fechado', fechado_em: new Date().toISOString() })
      .eq('id', id);
  },
};

// ============================================================
// AVALIAÇÕES
// ============================================================
const avaliacoes = {
  async criar(avaliacao) {
    const { data, error } = await supabase
      .from('avaliacoes')
      .insert([avaliacao])
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async listar(limite = 10) {
    const { data } = await supabase
      .from('avaliacoes')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limite);
    return data || [];
  },
};

const config_req = require('../../config');

module.exports = { supabase, produtos, pedidos, cupons, usuarios, tickets, avaliacoes };
