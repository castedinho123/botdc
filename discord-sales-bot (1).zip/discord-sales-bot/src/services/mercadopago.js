const { MercadoPagoConfig, Payment, MerchantOrder } = require('mercadopago');
const config = require('../../config');

const mpClient = new MercadoPagoConfig({
  accessToken: config.mercadoPago.accessToken,
  options: { timeout: 5000 },
});

const paymentClient = new Payment(mpClient);

/**
 * Cria uma preferência de pagamento Pix no Mercado Pago
 */
async function criarPagamentoPix({ valor, descricao, txid, email = 'cliente@email.com' }) {
  const pagamento = await paymentClient.create({
    body: {
      transaction_amount: valor,
      description: descricao,
      payment_method_id: 'pix',
      payer: {
        email,
        first_name: 'Cliente',
        last_name: 'Discord',
        identification: { type: 'CPF', number: '00000000000' },
      },
      external_reference: txid,
      notification_url: process.env.WEBHOOK_URL || undefined,
      date_of_expiration: new Date(
        Date.now() + config.payment.expiryMinutes * 60 * 1000
      ).toISOString(),
    },
  });

  return {
    id: pagamento.id,
    status: pagamento.status,
    pixCopiaECola: pagamento.point_of_interaction?.transaction_data?.qr_code,
    qrCodeBase64: pagamento.point_of_interaction?.transaction_data?.qr_code_base64,
  };
}

/**
 * Verifica o status de um pagamento
 */
async function verificarPagamento(paymentId) {
  const pagamento = await paymentClient.get({ id: paymentId });
  return {
    id: pagamento.id,
    status: pagamento.status,
    statusDetail: pagamento.status_detail,
    valor: pagamento.transaction_amount,
    externalReference: pagamento.external_reference,
    aprovado: pagamento.status === 'approved',
  };
}

module.exports = { criarPagamentoPix, verificarPagamento };
