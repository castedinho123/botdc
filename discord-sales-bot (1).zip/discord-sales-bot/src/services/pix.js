const QRCode = require('qrcode');
const config = require('../../config');

/**
 * Gera payload Pix (EMV/CRC16) padrão Banco Central
 */
function gerarPayloadPix({ chave, nome, cidade, valor, txid = '', descricao = '' }) {
  const format = (id, value) => {
    const len = value.length.toString().padStart(2, '0');
    return `${id}${len}${value}`;
  };

  const merchantAccountInfo = format('00', 'BR.GOV.BCB.PIX') + format('01', chave) +
    (descricao ? format('02', descricao.substring(0, 72)) : '');
  const txidClean = txid.replace(/[^a-zA-Z0-9]/g, '').substring(0, 25) || '***';

  const payload =
    format('00', '01') +
    format('26', merchantAccountInfo) +
    format('52', '0000') +
    format('53', '986') +
    format('54', valor.toFixed(2)) +
    format('58', 'BR') +
    format('59', nome.substring(0, 25)) +
    format('60', cidade.substring(0, 15)) +
    format('62', format('05', txidClean)) +
    '6304';

  const crc = calcularCRC16(payload);
  return payload + crc;
}

function calcularCRC16(str) {
  let crc = 0xFFFF;
  for (let i = 0; i < str.length; i++) {
    crc ^= str.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      crc = crc & 0x8000 ? (crc << 1) ^ 0x1021 : crc << 1;
    }
  }
  return ((crc & 0xFFFF).toString(16).toUpperCase()).padStart(4, '0');
}

async function gerarPix({ valor, txid, descricao }) {
  const payload = gerarPayloadPix({
    chave: config.pix.chave,
    nome: config.pix.nome,
    cidade: config.pix.cidade,
    valor,
    txid,
    descricao,
  });

  const qrCodeBuffer = await QRCode.toBuffer(payload, {
    errorCorrectionLevel: 'M',
    type: 'png',
    width: 400,
    margin: 2,
    color: { dark: '#000000', light: '#FFFFFF' },
  });

  return { payload, qrCodeBuffer };
}

module.exports = { gerarPix };
