const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const config = require('../../config');

let client = null;

function setClient(c) { client = c; }

async function enviarLog(tipo, dados) {
  if (!client) return;
  const canal = await client.channels.fetch(config.channels.logs).catch(() => null);
  if (!canal) return;

  const cores = {
    compra: config.colors.success,
    pagamento: config.colors.gold,
    entrega: config.colors.primary,
    erro: config.colors.danger,
    ticket: config.colors.info,
    admin: config.colors.warning,
    bloqueio: config.colors.danger,
  };

  const icones = {
    compra: '🛒',
    pagamento: '💸',
    entrega: '📦',
    erro: '❌',
    ticket: '🎫',
    admin: '⚙️',
    bloqueio: '🔨',
  };

  const embed = new EmbedBuilder()
    .setColor(cores[tipo] || config.colors.primary)
    .setTitle(`${icones[tipo] || '📋'} Log — ${tipo.toUpperCase()}`)
    .setTimestamp();

  for (const [key, val] of Object.entries(dados)) {
    if (val !== undefined && val !== null) {
      embed.addFields({ name: key, value: String(val).substring(0, 1024), inline: true });
    }
  }

  await canal.send({ embeds: [embed] }).catch(() => {});
}

module.exports = { setClient, enviarLog };
