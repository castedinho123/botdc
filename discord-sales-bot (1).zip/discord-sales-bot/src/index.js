require('dotenv').config();
const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const config = require('../config');
const logger = require('./services/logger');
const delivery = require('./services/delivery');
const cron = require('./handlers/cronHandler');
const { handleInteraction } = require('./handlers/interactionHandler');
const adminCommands = require('./commands/admin');

// ============================================================
// CLIENTE DISCORD
// ============================================================
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Channel, Partials.Message],
});

// Registra comandos
client.commands = new Collection();
for (const cmd of adminCommands) {
  client.commands.set(cmd.data.name, cmd);
}

// ============================================================
// EVENTOS
// ============================================================
client.once('ready', () => {
  console.log(`✅ Bot online como ${client.user.tag}`);
  console.log(`📦 ${config.store.name} — Pronto para vender!`);

  // Inicializa serviços com client
  logger.setClient(client);
  delivery.setClient(client);
  cron.setClient(client);
  cron.iniciar();

  client.user.setActivity(`${config.store.name} 🛒`, { type: 3 }); // Watching
});

client.on('interactionCreate', async (interaction) => {
  try {
    // Slash commands
    if (interaction.isChatInputCommand()) {
      const cmd = client.commands.get(interaction.commandName);
      if (cmd) return await cmd.execute(interaction);
    }

    // Buttons, selects, modals
    if (
      interaction.isButton() ||
      interaction.isStringSelectMenu() ||
      interaction.isModalSubmit()
    ) {
      return await handleInteraction(interaction);
    }
  } catch (err) {
    console.error('[INTERACTION ERROR]', err);
    await logger.enviarLog('erro', {
      '❌ Erro': err.message?.substring(0, 500),
      '📍 Local': `${interaction.commandName || interaction.customId}`,
      '👤 Usuário': `${interaction.user?.tag}`,
    });

    const msg = { embeds: [{ color: 0xED4245, title: '❌ Erro Interno', description: 'Ocorreu um erro. Tente novamente.' }], ephemeral: true };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(msg).catch(() => {});
    } else {
      await interaction.reply(msg).catch(() => {});
    }
  }
});

client.on('error', (err) => console.error('[CLIENT ERROR]', err));
process.on('unhandledRejection', (err) => console.error('[UNHANDLED]', err));

// ============================================================
// LOGIN
// ============================================================
client.login(config.discord.token);
