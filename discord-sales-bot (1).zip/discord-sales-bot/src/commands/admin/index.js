const {
  SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
} = require('discord.js');
const config = require('../../../config');
const db = require('../../services/database');
const embeds = require('../../utils/embeds');
const lojaUI = require('../shop/loja');
const { limparCooldown } = require('../../utils/antiSpam');

// ============================================================
// /produto criar
// ============================================================
const produtoCriar = {
  data: new SlashCommandBuilder()
    .setName('produto')
    .setDescription('Gerenciar produtos da loja')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub => sub
      .setName('criar')
      .setDescription('Criar um novo produto')
      .addStringOption(o => o.setName('nome').setDescription('Nome do produto').setRequired(true))
      .addNumberOption(o => o.setName('preco').setDescription('Preço em R$').setRequired(true))
      .addStringOption(o => o.setName('descricao').setDescription('Descrição completa').setRequired(true))
      .addStringOption(o => o.setName('tipo').setDescription('Tipo do produto').setRequired(true)
        .addChoices(
          { name: '💾 Digital (keys/contas/links)', value: 'digital' },
          { name: '👑 Cargo Discord', value: 'cargo' },
          { name: '📩 Manual', value: 'manual' }
        ))
      .addIntegerOption(o => o.setName('estoque').setDescription('Quantidade inicial em estoque').setRequired(false))
      .addStringOption(o => o.setName('emoji').setDescription('Emoji do produto').setRequired(false))
      .addStringOption(o => o.setName('descricao_curta').setDescription('Descrição curta (para lista)').setRequired(false))
      .addStringOption(o => o.setName('imagem_url').setDescription('URL da imagem principal').setRequired(false))
      .addStringOption(o => o.setName('thumbnail_url').setDescription('URL da thumbnail').setRequired(false))
      .addStringOption(o => o.setName('cargo_id').setDescription('ID do cargo (se tipo=cargo)').setRequired(false))
    )
    .addSubcommand(sub => sub
      .setName('editar')
      .setDescription('Editar um produto existente')
      .addStringOption(o => o.setName('id').setDescription('ID do produto').setRequired(true))
      .addStringOption(o => o.setName('nome').setDescription('Novo nome'))
      .addNumberOption(o => o.setName('preco').setDescription('Novo preço'))
      .addStringOption(o => o.setName('descricao').setDescription('Nova descrição'))
      .addStringOption(o => o.setName('emoji').setDescription('Novo emoji'))
      .addStringOption(o => o.setName('imagem_url').setDescription('Nova imagem'))
    )
    .addSubcommand(sub => sub
      .setName('deletar')
      .setDescription('Deletar um produto')
      .addStringOption(o => o.setName('id').setDescription('ID do produto').setRequired(true))
    )
    .addSubcommand(sub => sub
      .setName('listar')
      .setDescription('Listar todos os produtos')
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'criar') {
      const produto = await db.produtos.criar({
        nome: interaction.options.getString('nome'),
        preco: interaction.options.getNumber('preco'),
        descricao: interaction.options.getString('descricao'),
        descricao_curta: interaction.options.getString('descricao_curta') || '',
        tipo: interaction.options.getString('tipo'),
        estoque: interaction.options.getInteger('estoque') || 0,
        emoji: interaction.options.getString('emoji') || '📦',
        imagem_url: interaction.options.getString('imagem_url') || null,
        thumbnail_url: interaction.options.getString('thumbnail_url') || null,
        cargo_id: interaction.options.getString('cargo_id') || null,
        ativo: true,
      });
      return interaction.reply({ embeds: [embeds.sucesso('Produto Criado!', `**${produto.nome}** foi criado com ID: \`${produto.id}\``)], ephemeral: true });
    }

    if (sub === 'editar') {
      const id = interaction.options.getString('id');
      const atualizacoes = {};
      const campos = ['nome', 'descricao', 'emoji', 'imagem_url'];
      for (const c of campos) {
        const v = interaction.options.getString(c);
        if (v) atualizacoes[c] = v;
      }
      const preco = interaction.options.getNumber('preco');
      if (preco) atualizacoes.preco = preco;

      if (!Object.keys(atualizacoes).length) {
        return interaction.reply({ embeds: [embeds.aviso('Nada a atualizar', 'Forneça pelo menos um campo para editar.')], ephemeral: true });
      }
      const prod = await db.produtos.atualizar(id, atualizacoes);
      return interaction.reply({ embeds: [embeds.sucesso('Produto Atualizado!', `**${prod.nome}** foi atualizado.`)], ephemeral: true });
    }

    if (sub === 'deletar') {
      const id = interaction.options.getString('id');
      const prod = await db.produtos.buscarPorId(id);
      if (!prod) return interaction.reply({ embeds: [embeds.erro('Não Encontrado', 'Produto não existe.')], ephemeral: true });
      await db.produtos.deletar(id);
      return interaction.reply({ embeds: [embeds.sucesso('Deletado', `**${prod.nome}** foi removido da loja.`)], ephemeral: true });
    }

    if (sub === 'listar') {
      const lista = await db.produtos.listar();
      if (!lista?.length) return interaction.reply({ embeds: [embeds.aviso('Sem Produtos', 'Nenhum produto cadastrado.')], ephemeral: true });
      const linhas = lista.map(p =>
        `${p.emoji} **${p.nome}** — R$ ${p.preco.toFixed(2)} | 📦 ${p.estoque} | \`${p.id}\``
      ).join('\n');
      return interaction.reply({ embeds: [embeds.sucesso(`Produtos (${lista.length})`, linhas)], ephemeral: true });
    }
  },
};

// ============================================================
// /estoque
// ============================================================
const estoque = {
  data: new SlashCommandBuilder()
    .setName('estoque')
    .setDescription('Gerenciar estoque de produtos')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub => sub
      .setName('adicionar')
      .setDescription('Adicionar itens ao estoque (keys/contas/links)')
      .addStringOption(o => o.setName('produto_id').setDescription('ID do produto').setRequired(true))
      .addStringOption(o => o.setName('itens').setDescription('Itens separados por | (ex: key1|key2|key3)').setRequired(true))
    )
    .addSubcommand(sub => sub
      .setName('ver')
      .setDescription('Ver estoque de um produto')
      .addStringOption(o => o.setName('produto_id').setDescription('ID do produto').setRequired(true))
    )
    .addSubcommand(sub => sub
      .setName('definir')
      .setDescription('Definir quantidade de estoque (para produtos sem itens digitais)')
      .addStringOption(o => o.setName('produto_id').setDescription('ID do produto').setRequired(true))
      .addIntegerOption(o => o.setName('quantidade').setDescription('Nova quantidade').setRequired(true))
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'adicionar') {
      const prodId = interaction.options.getString('produto_id');
      const raw = interaction.options.getString('itens');
      const itens = raw.split('|').map(s => s.trim()).filter(Boolean);
      await db.produtos.adicionarEstoque(prodId, itens);
      return interaction.reply({ embeds: [embeds.sucesso('Estoque Atualizado', `${itens.length} item(s) adicionado(s) ao estoque.`)], ephemeral: true });
    }

    if (sub === 'ver') {
      const prodId = interaction.options.getString('produto_id');
      const prod = await db.produtos.buscarPorId(prodId);
      if (!prod) return interaction.reply({ embeds: [embeds.erro('Não Encontrado', 'Produto não existe.')], ephemeral: true });
      return interaction.reply({ embeds: [embeds.sucesso(`Estoque: ${prod.nome}`, `📦 **${prod.estoque}** unidade(s) disponível(is)`)], ephemeral: true });
    }

    if (sub === 'definir') {
      const prodId = interaction.options.getString('produto_id');
      const qty = interaction.options.getInteger('quantidade');
      await db.produtos.atualizar(prodId, { estoque: qty });
      return interaction.reply({ embeds: [embeds.sucesso('Estoque Definido', `Estoque definido para **${qty}** unidade(s).`)], ephemeral: true });
    }
  },
};

// ============================================================
// /cupom
// ============================================================
const cupom = {
  data: new SlashCommandBuilder()
    .setName('cupom')
    .setDescription('Gerenciar cupons de desconto')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub => sub
      .setName('criar')
      .setDescription('Criar um cupom de desconto')
      .addStringOption(o => o.setName('codigo').setDescription('Código do cupom').setRequired(true))
      .addIntegerOption(o => o.setName('desconto').setDescription('Percentual de desconto (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
      .addIntegerOption(o => o.setName('usos').setDescription('Máximo de usos (0 = ilimitado)').setRequired(false))
    )
    .addSubcommand(sub => sub
      .setName('listar')
      .setDescription('Listar todos os cupons')
    )
    .addSubcommand(sub => sub
      .setName('desativar')
      .setDescription('Desativar um cupom')
      .addStringOption(o => o.setName('codigo').setDescription('Código do cupom').setRequired(true))
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'criar') {
      const cupon = await db.cupons.criar({
        codigo: interaction.options.getString('codigo'),
        desconto: interaction.options.getInteger('desconto'),
        usos_maximos: interaction.options.getInteger('usos') || null,
        usos_atuais: 0,
        ativo: true,
      });
      return interaction.reply({ embeds: [embeds.sucesso('Cupom Criado!', `🏷️ Código: \`${cupon.codigo}\`\n💸 Desconto: **${cupon.desconto}%**`)], ephemeral: true });
    }

    if (sub === 'listar') {
      const lista = await db.cupons.listar();
      if (!lista?.length) return interaction.reply({ embeds: [embeds.aviso('Sem Cupons', 'Nenhum cupom cadastrado.')], ephemeral: true });
      const linhas = lista.map(c =>
        `${c.ativo ? '✅' : '❌'} \`${c.codigo}\` — **${c.desconto}%** | Usos: ${c.usos_atuais}${c.usos_maximos ? `/${c.usos_maximos}` : ''}`
      ).join('\n');
      return interaction.reply({ embeds: [embeds.sucesso(`Cupons (${lista.length})`, linhas)], ephemeral: true });
    }

    if (sub === 'desativar') {
      const codigo = interaction.options.getString('codigo').toUpperCase();
      await require('../../services/database').supabase
        .from('cupons').update({ ativo: false }).eq('codigo', codigo);
      return interaction.reply({ embeds: [embeds.sucesso('Cupom Desativado', `O cupom \`${codigo}\` foi desativado.`)], ephemeral: true });
    }
  },
};

// ============================================================
// /usuario
// ============================================================
const usuario = {
  data: new SlashCommandBuilder()
    .setName('usuario')
    .setDescription('Gerenciar usuários')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub => sub
      .setName('bloquear')
      .setDescription('Bloquear um usuário')
      .addUserOption(o => o.setName('usuario').setDescription('Usuário a bloquear').setRequired(true))
      .addStringOption(o => o.setName('motivo').setDescription('Motivo do bloqueio').setRequired(false))
    )
    .addSubcommand(sub => sub
      .setName('desbloquear')
      .setDescription('Desbloquear um usuário')
      .addUserOption(o => o.setName('usuario').setDescription('Usuário a desbloquear').setRequired(true))
    )
    .addSubcommand(sub => sub
      .setName('historico')
      .setDescription('Ver histórico de compras de um usuário')
      .addUserOption(o => o.setName('usuario').setDescription('Usuário').setRequired(true))
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const target = interaction.options.getUser('usuario');

    if (sub === 'bloquear') {
      const motivo = interaction.options.getString('motivo') || 'Sem motivo';
      await db.usuarios.bloquear(target.id, motivo);
      limparCooldown(target.id);
      return interaction.reply({ embeds: [embeds.sucesso('Usuário Bloqueado', `${target.tag} foi bloqueado.\nMotivo: ${motivo}`)], ephemeral: true });
    }

    if (sub === 'desbloquear') {
      await db.usuarios.desbloquear(target.id);
      return interaction.reply({ embeds: [embeds.sucesso('Desbloqueado', `${target.tag} foi desbloqueado.`)], ephemeral: true });
    }

    if (sub === 'historico') {
      const pedidosUser = await db.pedidos.buscarPorUsuario(target.id);
      if (!pedidosUser?.length) return interaction.reply({ embeds: [embeds.aviso('Sem Histórico', `${target.tag} não tem compras.`)], ephemeral: true });
      const linhas = pedidosUser.map(p =>
        `${p.status === 'entregue' ? '✅' : '⏳'} \`#${p.id.substring(0, 8).toUpperCase()}\` — R$ ${p.valor?.toFixed(2)} — ${new Date(p.created_at).toLocaleDateString('pt-BR')}`
      ).join('\n');
      return interaction.reply({ embeds: [embeds.sucesso(`Histórico: ${target.tag}`, linhas)], ephemeral: true });
    }
  },
};

// ============================================================
// /loja (painel admin)
// ============================================================
const lojaAdmin = {
  data: new SlashCommandBuilder()
    .setName('loja')
    .setDescription('Comandos da loja')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub => sub
      .setName('painel')
      .setDescription('Publicar/atualizar painel da loja no canal atual')
    )
    .addSubcommand(sub => sub
      .setName('pedido')
      .setDescription('Ver detalhes de um pedido')
      .addStringOption(o => o.setName('id').setDescription('ID do pedido').setRequired(true))
    )
    .addSubcommand(sub => sub
      .setName('confirmar_pagamento')
      .setDescription('Confirmar pagamento manualmente')
      .addStringOption(o => o.setName('pedido_id').setDescription('ID do pedido').setRequired(true))
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'painel') {
      await interaction.deferReply();
      const painel = await lojaUI.enviarPainelLoja(interaction.channel);
      await interaction.channel.send(painel);
      return interaction.editReply({ content: '✅ Painel publicado!', ephemeral: true });
    }

    if (sub === 'pedido') {
      const id = interaction.options.getString('id');
      const pedido = await db.pedidos.buscarPorId(id);
      if (!pedido) return interaction.reply({ embeds: [embeds.erro('Não Encontrado', 'Pedido não existe.')], ephemeral: true });
      const info = Object.entries(pedido)
        .filter(([, v]) => v !== null)
        .map(([k, v]) => `**${k}**: ${v}`)
        .join('\n');
      return interaction.reply({ embeds: [embeds.sucesso(`Pedido #${id.substring(0, 8).toUpperCase()}`, info.substring(0, 4000))], ephemeral: true });
    }

    if (sub === 'confirmar_pagamento') {
      const pedidoId = interaction.options.getString('pedido_id');
      const pedido = await db.pedidos.buscarPorId(pedidoId);
      if (!pedido) return interaction.reply({ embeds: [embeds.erro('Não Encontrado', 'Pedido não existe.')], ephemeral: true });
      await db.pedidos.atualizar(pedidoId, { status: 'pago' });
      await require('../shop/payment').confirmarPagamento(pedidoId, interaction, pedido.valor);
      return interaction.reply({ embeds: [embeds.sucesso('Confirmado', 'Pagamento confirmado manualmente e produto entregue.')], ephemeral: true });
    }
  },
};

module.exports = [produtoCriar, estoque, cupom, usuario, lojaAdmin];
