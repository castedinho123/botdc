const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder, EmbedBuilder,
} = require('discord.js');
const config = require('../../../config');
const db = require('../../services/database');
const embeds = require('../../utils/embeds');

/**
 * Envia/atualiza o painel da loja em um canal
 */
async function enviarPainelLoja(channel) {
  const produtos = await db.produtos.listar();

  const embed = embeds.loja();

  if (produtos.length === 0) {
    embed.addFields({ name: 'Sem produtos', value: 'Nenhum produto disponível no momento.' });
  } else {
    for (const p of produtos.slice(0, 20)) {
      embed.addFields({
        name: `${p.emoji || '📦'} ${p.nome}`,
        value: `💰 R$ ${p.preco.toFixed(2)} | 📦 ${p.estoque > 0 ? `${p.estoque} em estoque` : '**Esgotado**'}\n${p.descricao_curta || ''}`,
        inline: true,
      });
    }
  }

  const rows = [];

  // Dropdown de produtos (até 25 itens)
  if (produtos.length > 0) {
    const options = produtos.slice(0, 25).map(p => ({
      label: p.nome.substring(0, 100),
      description: `R$ ${p.preco.toFixed(2)} • ${p.descricao_curta?.substring(0, 100) || 'Clique para ver mais'}`,
      value: p.id,
      emoji: p.emoji || '📦',
    }));

    rows.push(new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('shop_select_produto')
        .setPlaceholder(`${config.emojis.cart} Selecione um produto para ver detalhes...`)
        .addOptions(options)
    ));
  }

  // Botões principais
  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('shop_ver_carrinho')
      .setLabel('Ver Carrinho')
      .setEmoji('🛒')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('shop_historico')
      .setLabel('Meu Histórico')
      .setEmoji('📋')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('shop_avaliar')
      .setLabel('Avaliar')
      .setEmoji('⭐')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('shop_suporte')
      .setLabel('Suporte')
      .setEmoji('🎫')
      .setStyle(ButtonStyle.Secondary)
  ));

  return { embeds: [embed], components: rows };
}

/**
 * Monta mensagem de detalhes de um produto com botões de ação
 */
function mensagemProduto(produto) {
  const embed = embeds.produto(produto);

  const rows = [];

  const botoesCompra = new ActionRowBuilder();

  if (produto.estoque > 0) {
    botoesCompra.addComponents(
      new ButtonBuilder()
        .setCustomId(`shop_comprar_${produto.id}`)
        .setLabel('Comprar Agora')
        .setEmoji('💰')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`shop_add_carrinho_${produto.id}`)
        .setLabel('Adicionar ao Carrinho')
        .setEmoji('🛒')
        .setStyle(ButtonStyle.Primary)
    );
  } else {
    botoesCompra.addComponents(
      new ButtonBuilder()
        .setCustomId('shop_sem_estoque')
        .setLabel('Sem Estoque')
        .setEmoji('❌')
        .setStyle(ButtonStyle.Danger)
        .setDisabled(true)
    );
  }

  botoesCompra.addComponents(
    new ButtonBuilder()
      .setCustomId('shop_voltar_loja')
      .setLabel('Voltar')
      .setEmoji('◀️')
      .setStyle(ButtonStyle.Secondary)
  );

  rows.push(botoesCompra);

  // Dropdown de quantidade (1-5)
  if (produto.estoque > 0) {
    const maxQtd = Math.min(produto.estoque, 5);
    const qtdOptions = Array.from({ length: maxQtd }, (_, i) => ({
      label: `${i + 1} unidade${i > 0 ? 's' : ''}`,
      value: `${i + 1}`,
      description: `R$ ${((i + 1) * produto.preco).toFixed(2)} no total`,
      emoji: i === 0 ? '1️⃣' : i === 1 ? '2️⃣' : i === 2 ? '3️⃣' : i === 3 ? '4️⃣' : '5️⃣',
    }));
    rows.push(new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(`shop_qtd_${produto.id}`)
        .setPlaceholder('Quantidade: 1 unidade')
        .addOptions(qtdOptions)
    ));
  }

  return { embeds: [embed], components: rows, ephemeral: true };
}

/**
 * Monta embed e botões do carrinho
 */
function mensagemCarrinho(itens, totais, cupom = null) {
  const embed = embeds.carrinho(itens, totais, cupom);
  const rows = [];

  if (itens.length > 0) {
    // Dropdown para remover itens
    const removeOptions = itens.map(i => ({
      label: `Remover: ${i.nome}`,
      value: i.produtoId,
      emoji: i.emoji || '📦',
      description: `R$ ${(i.preco * i.quantidade).toFixed(2)}`,
    }));
    rows.push(new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('cart_remover_item')
        .setPlaceholder('🗑️ Remover um item do carrinho...')
        .addOptions(removeOptions)
    ));

    rows.push(new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('cart_pagar_pix')
        .setLabel('Pagar com Pix')
        .setEmoji('💸')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('cart_pagar_mp')
        .setLabel('Mercado Pago')
        .setEmoji('💳')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('cart_cupom')
        .setLabel('Cupom')
        .setEmoji('🏷️')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('cart_limpar')
        .setLabel('Limpar')
        .setEmoji('🗑️')
        .setStyle(ButtonStyle.Danger)
    ));
  } else {
    rows.push(new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('shop_voltar_loja')
        .setLabel('Ir para a Loja')
        .setEmoji('🛒')
        .setStyle(ButtonStyle.Primary)
    ));
  }

  return { embeds: [embed], components: rows, ephemeral: true };
}

module.exports = { enviarPainelLoja, mensagemProduto, mensagemCarrinho };
