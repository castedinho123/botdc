const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder } = require('discord.js');
const { v4: uuidv4 } = require('uuid');
const config = require('../../../config');
const db = require('../../services/database');
const cart = require('../../utils/cart');
const embeds = require('../../utils/embeds');
const pixService = require('../../services/pix');
const mpService = require('../../services/mercadopago');
const logger = require('../../services/logger');
const delivery = require('../../services/delivery');

// Armazena verificadores ativos: paymentId -> intervalId
const verificadores = new Map();

/**
 * Inicia checkout via Pix (nativo BR)
 */
async function iniciarCheckoutPix(interaction, desconto = 0) {
  const userId = interaction.user.id;
  const itens = cart.obter(userId);
  if (!itens.length) return interaction.reply({ embeds: [embeds.erro('Carrinho Vazio', 'Adicione produtos antes de pagar.')], ephemeral: true });

  const totais = cart.calcularTotal(userId, desconto);
  await interaction.deferReply({ ephemeral: true });

  // Cria pedido no banco
  const pedidoId = uuidv4();
  const expiry = Date.now() + config.payment.expiryMinutes * 60 * 1000;

  const pedido = await db.pedidos.criar({
    id: pedidoId,
    usuario_id: userId,
    usuario_tag: interaction.user.tag,
    valor: totais.total,
    desconto: totais.desconto,
    status: 'pendente',
    metodo: 'pix_nativo',
    expires_at: new Date(expiry).toISOString(),
  });

  // Cria itens do pedido
  await db.pedidos.criarItens(itens.map(i => ({
    pedido_id: pedidoId,
    produto_id: i.produtoId,
    nome_produto: i.nome,
    preco_unitario: i.preco,
    quantidade: i.quantidade,
  })));

  // Gera Pix
  const { payload, qrCodeBuffer } = await pixService.gerarPix({
    valor: totais.total,
    txid: pedidoId.replace(/-/g, '').substring(0, 25),
    descricao: `Pedido ${config.store.name}`.substring(0, 72),
  });

  const attachment = new AttachmentBuilder(qrCodeBuffer, { name: 'pix-qrcode.png' });

  const embed = embeds.pagamentoPix(pedidoId, totais.total, expiry)
    .setImage('attachment://pix-qrcode.png');

  embed.addFields({ name: '📋 Código Pix (Copia e Cola)', value: `\`\`\`${payload}\`\`\``, inline: false });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`pag_verificar_${pedidoId}`)
      .setLabel('Verificar Pagamento')
      .setEmoji('🔄')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`pag_cancelar_${pedidoId}`)
      .setLabel('Cancelar')
      .setEmoji('❌')
      .setStyle(ButtonStyle.Danger)
  );

  await interaction.editReply({ embeds: [embed], files: [attachment], components: [row] });

  // Limpa carrinho
  cart.limpar(userId);

  // Inicia verificação automática a cada 15s
  iniciarVerificacaoAutomatica(pedidoId, interaction, totais.total);

  await logger.enviarLog('pagamento', {
    '🆔 Pedido': `#${pedidoId.substring(0, 8).toUpperCase()}`,
    '👤 Usuário': `${interaction.user.tag}`,
    '💰 Valor': `R$ ${totais.total.toFixed(2)}`,
    '💳 Método': 'Pix Nativo',
    '📦 Status': 'Aguardando',
  });
}

/**
 * Inicia checkout via Mercado Pago
 */
async function iniciarCheckoutMP(interaction, desconto = 0) {
  const userId = interaction.user.id;
  const itens = cart.obter(userId);
  if (!itens.length) return interaction.reply({ embeds: [embeds.erro('Carrinho Vazio', 'Adicione produtos antes de pagar.')], ephemeral: true });

  const totais = cart.calcularTotal(userId, desconto);
  await interaction.deferReply({ ephemeral: true });

  const pedidoId = uuidv4();
  const expiry = Date.now() + config.payment.expiryMinutes * 60 * 1000;

  await db.pedidos.criar({
    id: pedidoId,
    usuario_id: userId,
    usuario_tag: interaction.user.tag,
    valor: totais.total,
    desconto: totais.desconto,
    status: 'pendente',
    metodo: 'mercado_pago',
    expires_at: new Date(expiry).toISOString(),
  });

  await db.pedidos.criarItens(itens.map(i => ({
    pedido_id: pedidoId,
    produto_id: i.produtoId,
    nome_produto: i.nome,
    preco_unitario: i.preco,
    quantidade: i.quantidade,
  })));

  const pagMP = await mpService.criarPagamentoPix({
    valor: totais.total,
    descricao: `Pedido ${config.store.name}`,
    txid: pedidoId,
    email: `${interaction.user.id}@discord.user`,
  });

  await db.pedidos.atualizar(pedidoId, { payment_id: String(pagMP.id) });

  const embed = embeds.pagamentoPix(pedidoId, totais.total, expiry)
    .setTitle('💳 Pagamento via Mercado Pago (Pix)');

  if (pagMP.pixCopiaECola) {
    embed.addFields({ name: '📋 Código Pix MP', value: `\`\`\`${pagMP.pixCopiaECola}\`\`\``, inline: false });
  }

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`pag_verificar_mp_${pedidoId}`)
      .setLabel('Verificar Pagamento')
      .setEmoji('🔄')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`pag_cancelar_${pedidoId}`)
      .setLabel('Cancelar')
      .setEmoji('❌')
      .setStyle(ButtonStyle.Danger)
  );

  let files = [];
  if (pagMP.qrCodeBase64) {
    const buf = Buffer.from(pagMP.qrCodeBase64, 'base64');
    const att = new AttachmentBuilder(buf, { name: 'mp-qrcode.png' });
    embed.setImage('attachment://mp-qrcode.png');
    files = [att];
  }

  await interaction.editReply({ embeds: [embed], files, components: [row] });
  cart.limpar(userId);
  iniciarVerificacaoMP(pedidoId, String(pagMP.id), interaction, totais.total);
}

/**
 * Verificação automática — Pix nativo (por enquanto polling de DB)
 */
function iniciarVerificacaoAutomatica(pedidoId, interaction, valor) {
  let tentativas = 0;
  const maxTentativas = Math.ceil(config.payment.expiryMinutes * 60 / 15);

  const interval = setInterval(async () => {
    tentativas++;
    const pedido = await db.pedidos.buscarPorId(pedidoId);
    if (!pedido || pedido.status === 'cancelado') {
      clearInterval(interval);
      verificadores.delete(pedidoId);
      return;
    }
    if (pedido.status === 'pago') {
      clearInterval(interval);
      verificadores.delete(pedidoId);
      await confirmarPagamento(pedidoId, interaction, valor);
      return;
    }
    if (tentativas >= maxTentativas) {
      clearInterval(interval);
      verificadores.delete(pedidoId);
      await db.pedidos.atualizar(pedidoId, { status: 'expirado' });
    }
  }, 15_000);

  verificadores.set(pedidoId, interval);
}

/**
 * Verificação automática — Mercado Pago
 */
function iniciarVerificacaoMP(pedidoId, paymentId, interaction, valor) {
  let tentativas = 0;
  const maxTentativas = Math.ceil(config.payment.expiryMinutes * 60 / 15);

  const interval = setInterval(async () => {
    tentativas++;
    try {
      const resultado = await mpService.verificarPagamento(paymentId);
      if (resultado.aprovado) {
        clearInterval(interval);
        verificadores.delete(pedidoId);
        await db.pedidos.atualizar(pedidoId, { status: 'pago', payment_id: paymentId });
        await confirmarPagamento(pedidoId, interaction, valor);
        return;
      }
    } catch {}
    if (tentativas >= maxTentativas) {
      clearInterval(interval);
      verificadores.delete(pedidoId);
      await db.pedidos.atualizar(pedidoId, { status: 'expirado' });
    }
  }, 15_000);

  verificadores.set(pedidoId, interval);
}

/**
 * Confirma pagamento e entrega
 */
async function confirmarPagamento(pedidoId, interaction, valor) {
  const guild = interaction.guild;

  const embed = embeds.pedidoConfirmado(pedidoId, interaction.user.id, valor);
  await interaction.followUp({ embeds: [embed], ephemeral: true }).catch(() => {});

  // Entrega o produto
  await delivery.entregarPedido(pedidoId, guild);

  await logger.enviarLog('compra', {
    '✅ Pedido': `#${pedidoId.substring(0, 8).toUpperCase()}`,
    '👤 Usuário': `${interaction.user.tag} (${interaction.user.id})`,
    '💰 Valor': `R$ ${valor.toFixed(2)}`,
    '📅 Data': new Date().toLocaleString('pt-BR'),
  });
}

/**
 * Cancela pedido e para verificação
 */
async function cancelarPedido(pedidoId) {
  const interval = verificadores.get(pedidoId);
  if (interval) {
    clearInterval(interval);
    verificadores.delete(pedidoId);
  }
  await db.pedidos.atualizar(pedidoId, { status: 'cancelado' });
}

module.exports = { iniciarCheckoutPix, iniciarCheckoutMP, confirmarPagamento, cancelarPedido };
