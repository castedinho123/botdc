const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const config = require('../../config');
const db = require('../services/database');
const cart = require('../utils/cart');
const embeds = require('../utils/embeds');
const lojaUI = require('../commands/shop/loja');
const payment = require('../commands/shop/payment');
const { verificarCooldown, verificarBloqueio } = require('../utils/antiSpam');

// Cache de quantidades selecionadas: userId -> qtd
const quantidadesSelecionadas = new Map();
// Cache de cupons aplicados: userId -> cupon
const cuponsAplicados = new Map();

async function handleInteraction(interaction) {
  const userId = interaction.user.id;

  // Verifica bloqueio
  if (await verificarBloqueio(userId)) {
    return interaction.reply({ embeds: [embeds.erro('Acesso Negado', 'Sua conta está bloqueada. Entre em contato com o suporte.')], ephemeral: true });
  }

  // Anti-spam
  const spam = verificarCooldown(userId, interaction.customId?.split('_')[0] || 'geral');
  if (spam.bloqueado) {
    return interaction.reply({ embeds: [embeds.aviso('Calma aí!', `Aguarde ${spam.restante}s antes de usar novamente.`)], ephemeral: true }).catch(() => {});
  }

  const id = interaction.customId;

  // ============================================================
  // BOTÕES DA LOJA
  // ============================================================
  if (id === 'shop_ver_carrinho') {
    const itens = cart.obter(userId);
    const cupom = cuponsAplicados.get(userId);
    const totais = cart.calcularTotal(userId, cupom?.desconto || 0);
    return interaction.reply(lojaUI.mensagemCarrinho(itens, totais, cupom));
  }

  if (id === 'shop_voltar_loja') {
    const painel = await lojaUI.enviarPainelLoja(interaction.channel);
    return interaction.reply({ ...painel, ephemeral: true });
  }

  if (id === 'shop_historico') {
    const pedidosUser = await db.pedidos.buscarPorUsuario(userId);
    if (!pedidosUser?.length) {
      return interaction.reply({ embeds: [embeds.aviso('Sem Histórico', 'Você ainda não fez nenhuma compra.')], ephemeral: true });
    }
    const linhas = pedidosUser.slice(0, 10).map(p => {
      const status = { pago: '✅', entregue: '📦', pendente: '⏳', cancelado: '❌', expirado: '⏰' }[p.status] || '❓';
      const data = new Date(p.created_at).toLocaleDateString('pt-BR');
      return `${status} \`#${p.id.substring(0, 8).toUpperCase()}\` — R$ ${p.valor?.toFixed(2)} — ${data}`;
    }).join('\n');
    return interaction.reply({ embeds: [embeds.sucesso('Histórico de Compras', linhas)], ephemeral: true });
  }

  if (id === 'shop_suporte') {
    return interaction.reply({ embeds: [embeds.sucesso('Suporte', `Entre em contato com um administrador ou use \`/ticket\``)], ephemeral: true });
  }

  // ============================================================
  // SELEÇÃO DE PRODUTO
  // ============================================================
  if (id === 'shop_select_produto') {
    const produtoId = interaction.values[0];
    const produto = await db.produtos.buscarPorId(produtoId);
    if (!produto) return interaction.reply({ embeds: [embeds.erro('Erro', 'Produto não encontrado.')], ephemeral: true });
    return interaction.reply(lojaUI.mensagemProduto(produto));
  }

  // Seleção de quantidade
  if (id.startsWith('shop_qtd_')) {
    const qtd = parseInt(interaction.values[0]);
    quantidadesSelecionadas.set(userId, qtd);
    return interaction.reply({ embeds: [embeds.sucesso('Quantidade', `Quantidade definida para **${qtd}**. Agora clique em Comprar ou Adicionar ao Carrinho.`)], ephemeral: true });
  }

  // Comprar agora (direto)
  if (id.startsWith('shop_comprar_')) {
    const produtoId = id.replace('shop_comprar_', '');
    const qtd = quantidadesSelecionadas.get(userId) || 1;
    const produto = await db.produtos.buscarPorId(produtoId);
    if (!produto) return interaction.reply({ embeds: [embeds.erro('Erro', 'Produto não encontrado.')], ephemeral: true });

    cart.limpar(userId);
    const r = cart.adicionar(userId, produto, qtd);
    if (!r.sucesso) return interaction.reply({ embeds: [embeds.erro('Erro', r.motivo)], ephemeral: true });

    quantidadesSelecionadas.delete(userId);
    const cupom = cuponsAplicados.get(userId);
    const totais = cart.calcularTotal(userId, cupom?.desconto || 0);
    return interaction.reply(lojaUI.mensagemCarrinho(cart.obter(userId), totais, cupom));
  }

  // Adicionar ao carrinho
  if (id.startsWith('shop_add_carrinho_')) {
    const produtoId = id.replace('shop_add_carrinho_', '');
    const qtd = quantidadesSelecionadas.get(userId) || 1;
    const produto = await db.produtos.buscarPorId(produtoId);
    if (!produto) return interaction.reply({ embeds: [embeds.erro('Erro', 'Produto não encontrado.')], ephemeral: true });

    const r = cart.adicionar(userId, produto, qtd);
    if (!r.sucesso) return interaction.reply({ embeds: [embeds.erro('Erro', r.motivo)], ephemeral: true });

    quantidadesSelecionadas.delete(userId);
    return interaction.reply({ embeds: [embeds.sucesso('Carrinho', `**${produto.nome}** (x${qtd}) adicionado ao carrinho! 🛒`)], ephemeral: true });
  }

  // ============================================================
  // CARRINHO
  // ============================================================
  if (id === 'cart_remover_item') {
    const produtoId = interaction.values[0];
    cart.remover(userId, produtoId);
    const cupom = cuponsAplicados.get(userId);
    const totais = cart.calcularTotal(userId, cupom?.desconto || 0);
    return interaction.update(lojaUI.mensagemCarrinho(cart.obter(userId), totais, cupom));
  }

  if (id === 'cart_limpar') {
    cart.limpar(userId);
    cuponsAplicados.delete(userId);
    return interaction.update(lojaUI.mensagemCarrinho([], { subtotal: 0, desconto: 0, total: 0 }, null));
  }

  if (id === 'cart_pagar_pix') {
    const cupom = cuponsAplicados.get(userId);
    await interaction.deferUpdate();
    return payment.iniciarCheckoutPix(interaction, cupom?.desconto || 0);
  }

  if (id === 'cart_pagar_mp') {
    const cupom = cuponsAplicados.get(userId);
    await interaction.deferUpdate();
    return payment.iniciarCheckoutMP(interaction, cupom?.desconto || 0);
  }

  if (id === 'cart_cupom') {
    const modal = new ModalBuilder()
      .setCustomId('modal_cupom')
      .setTitle('🏷️ Aplicar Cupom de Desconto');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('codigo_cupom')
          .setLabel('Código do Cupom')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Ex: DESCONTO10')
          .setRequired(true)
          .setMaxLength(50)
      )
    );
    return interaction.showModal(modal);
  }

  // ============================================================
  // MODAIS
  // ============================================================
  if (id === 'modal_cupom') {
    const codigo = interaction.fields.getTextInputValue('codigo_cupom');
    const cupom = await db.cupons.buscarPorCodigo(codigo);
    if (!cupom) return interaction.reply({ embeds: [embeds.erro('Cupom Inválido', 'Este cupom não existe ou está expirado.')], ephemeral: true });

    cuponsAplicados.set(userId, cupom);
    await db.cupons.usar(cupom.id);
    const totais = cart.calcularTotal(userId, cupom.desconto);
    return interaction.reply({ embeds: [embeds.sucesso('Cupom Aplicado!', `🏷️ Desconto de **${cupom.desconto}%** aplicado!\nNovo total: **R$ ${totais.total.toFixed(2)}**`)], ephemeral: true });
  }

  // ============================================================
  // PAGAMENTO
  // ============================================================
  if (id.startsWith('pag_verificar_mp_')) {
    const pedidoId = id.replace('pag_verificar_mp_', '');
    const pedido = await db.pedidos.buscarPorId(pedidoId);
    if (!pedido) return interaction.reply({ embeds: [embeds.erro('Erro', 'Pedido não encontrado.')], ephemeral: true });
    if (pedido.status === 'pago' || pedido.status === 'entregue') {
      return interaction.reply({ embeds: [embeds.sucesso('Pago!', 'Este pedido já foi confirmado.')], ephemeral: true });
    }
    if (pedido.payment_id) {
      const resultado = await require('../services/mercadopago').verificarPagamento(pedido.payment_id);
      if (resultado.aprovado) {
        await db.pedidos.atualizar(pedidoId, { status: 'pago' });
        await payment.confirmarPagamento(pedidoId, interaction, pedido.valor);
        return interaction.reply({ embeds: [embeds.sucesso('Confirmado!', 'Pagamento aprovado!')], ephemeral: true });
      }
    }
    return interaction.reply({ embeds: [embeds.aviso('Aguardando', 'Pagamento ainda não identificado. Tente novamente em alguns instantes.')], ephemeral: true });
  }

  if (id.startsWith('pag_verificar_')) {
    const pedidoId = id.replace('pag_verificar_', '');
    const pedido = await db.pedidos.buscarPorId(pedidoId);
    if (!pedido) return interaction.reply({ embeds: [embeds.erro('Erro', 'Pedido não encontrado.')], ephemeral: true });
    if (pedido.status === 'pago' || pedido.status === 'entregue') {
      return interaction.reply({ embeds: [embeds.sucesso('Pago!', 'Este pedido já foi confirmado e entregue!')], ephemeral: true });
    }
    return interaction.reply({ embeds: [embeds.aviso('Aguardando', 'Verificação automática ativa. Aguarde até 15 segundos após pagar.')], ephemeral: true });
  }

  if (id.startsWith('pag_cancelar_')) {
    const pedidoId = id.replace('pag_cancelar_', '');
    await payment.cancelarPedido(pedidoId);
    return interaction.reply({ embeds: [embeds.aviso('Cancelado', 'Pedido cancelado com sucesso.')], ephemeral: true });
  }

  // ============================================================
  // AVALIAÇÃO
  // ============================================================
  if (id === 'shop_avaliar') {
    const modal = new ModalBuilder()
      .setCustomId('modal_avaliacao')
      .setTitle('⭐ Deixe sua Avaliação');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('comentario')
          .setLabel('Seu comentário')
          .setStyle(TextInputStyle.Paragraph)
          .setPlaceholder('Conte como foi sua experiência...')
          .setRequired(true)
          .setMaxLength(500)
      )
    );
    return interaction.showModal(modal);
  }

  if (id === 'modal_avaliacao') {
    const comentario = interaction.fields.getTextInputValue('comentario');
    await db.avaliacoes.criar({
      usuario_id: userId,
      usuario_tag: interaction.user.tag,
      estrelas: 5,
      comentario,
    });
    return interaction.reply({ embeds: [embeds.sucesso('Avaliação Enviada!', `⭐⭐⭐⭐⭐\n"${comentario}"\n\nObrigado pelo seu feedback!`)], ephemeral: true });
  }

  // ============================================================
  // TICKETS - Fechar
  // ============================================================
  if (id.startsWith('fechar_ticket_')) {
    const canalId = id.replace('fechar_ticket_', '');
    const canal = interaction.guild.channels.cache.get(canalId);
    if (canal) {
      await canal.send({ embeds: [embeds.aviso('Ticket Fechado', `Fechado por ${interaction.user.tag}`)] });
      await db.tickets.fechar(canalId);
      setTimeout(() => canal.delete().catch(() => {}), 5000);
    }
    return interaction.reply({ embeds: [embeds.sucesso('Fechado', 'O ticket será deletado em 5 segundos.')], ephemeral: true });
  }
}

module.exports = { handleInteraction, cuponsAplicados };
