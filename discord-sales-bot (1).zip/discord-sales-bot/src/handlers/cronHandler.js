const { CronJob } = require('cron');
const db = require('../services/database');
const logger = require('../services/logger');
const config = require('../../config');

let client = null;
function setClient(c) { client = c; }

/**
 * Verifica pedidos expirados a cada 5 minutos
 */
const jobPedidosExpirados = new CronJob('*/5 * * * *', async () => {
  try {
    const expirados = await db.pedidos.buscarExpirados();
    for (const pedido of expirados) {
      await db.pedidos.atualizar(pedido.id, { status: 'expirado' });
      await logger.enviarLog('pagamento', {
        '⏰ Pedido Expirado': `#${pedido.id.substring(0, 8).toUpperCase()}`,
        '👤 Usuário': pedido.usuario_tag,
        '💰 Valor': `R$ ${pedido.valor?.toFixed(2)}`,
      });
    }
  } catch (err) {
    console.error('[CRON] Erro ao expirar pedidos:', err.message);
  }
});

/**
 * Alerta de estoque baixo a cada hora
 */
const jobEstoqueBaixo = new CronJob('0 * * * *', async () => {
  try {
    const produtos = await db.produtos.listar();
    const baixoEstoque = produtos.filter(p => p.estoque <= 3 && p.estoque > 0);
    const semEstoque = produtos.filter(p => p.estoque === 0);

    if (!client) return;

    const canal = await client.channels.fetch(config.channels.logs).catch(() => null);
    if (!canal) return;

    if (semEstoque.length > 0) {
      await logger.enviarLog('erro', {
        '❌ Sem Estoque': semEstoque.map(p => p.nome).join(', '),
        '📋 Ação': 'Adicione estoque com /estoque adicionar',
      });
    }

    if (baixoEstoque.length > 0) {
      await logger.enviarLog('admin', {
        '⚠️ Estoque Baixo': baixoEstoque.map(p => `${p.nome} (${p.estoque})`).join(', '),
        '📋 Ação': 'Considere repor o estoque',
      });
    }
  } catch (err) {
    console.error('[CRON] Erro ao verificar estoque:', err.message);
  }
});

function iniciar() {
  jobPedidosExpirados.start();
  jobEstoqueBaixo.start();
  console.log('[CRON] Jobs iniciados.');
}

module.exports = { setClient, iniciar };
